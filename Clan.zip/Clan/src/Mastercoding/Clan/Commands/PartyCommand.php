<?php
/**
 * Created by PhpStorm.
 * User: mastercoding
 * Date: 07.03.19
 * Time: 00:01
 */

namespace Mastercoding\Clan\Commands;

use Mastercoding\Clan\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\ModalFormRequestPacket;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;
use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\utils\Config;

class PartyCommand extends Command implements Listener
{

    public static $member = [];

    public static $players = [];

    public function __construct($name, $description = "", $usageMessage = null, $aliases = [])
    {
        parent::__construct($name, $description, $usageMessage, $aliases);
    }

    public function execute(CommandSender $sender, string $alias, array $args)
    {
        if ($sender instanceof Player) {
            $this->openMainGui($sender);
        }
    }

    public function onConfig()
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "party.json", Config::JSON);
        $config->reload();
        return $config;
    }

    public function openMainGui(Player $player)
    {
        $name = $player->getName();
        $partyplayer = Main::$partyplayers[$name];
        $clanplayer = Main::$players[$name];

        $fdata = [];

        $fdata['title'] = "§5Party";
        $fdata['buttons'] = [];
        $fdata['content'] = "";
        $fdata['type'] = 'form';

        /*if (!$partyplayer->isInParty()) {
            $fdata["buttons"][] = ["text" => "§5Party §7erstellen"];
            $fdata["buttons"][] = ["text" => "§7Invites"];
            if ($clanplayer->isInClan()) {
                if ($clanplayer->isClanLeader()) {
                    $fdata["buttons"][] = ["text" => "§5Clan-Party"];
                }
                if ($clanplayer->isClanWarPlayer()) {
                    $fdata["buttons"][] = ["text" => "§7Clan-Party verlassen"];
                }
            }
        } elseif ($partyplayer->isInParty() and $partyplayer->isPartyOwner()) {
            $fdata["buttons"][] = ["text" => "§7Einladen"];
            $fdata["buttons"][] = ["text" => "§3Members"];
        }*/

        $pk = new ModalFormRequestPacket();
        $pk->formId = 5000;
        $pk->formData = json_encode($fdata);
        $player->sendDataPacket($pk);
    }

    public function invitePlayer(Player $player)
    {
        $name = $player->getName();
        $partyplayer = Main::$partyplayers[$name];
        $fdata = [];

        $fdata['title'] = "§5Party";
        $fdata['buttons'] = [];
        $fdata['content'] = [];
        $fdata['type'] = 'custom_form';

        $fdata['content'][] = ["type" => "input", "text" => '§7Spielername', "placeholder" => 'Name', 'default' => ''];

        $pk = new ModalFormRequestPacket();
        $pk->formId = 5001;
        $pk->formData = json_encode($fdata);
        $player->sendDataPacket($pk);
    }

    public function invites(Player $player)
    {
        $name = $player->getName();
        $partyplayer = Main::$partyplayers[$name];
        $fdata = [];

        $fdata['title'] = "§5Party";
        $fdata['buttons'] = [];
        $fdata['content'] = "";
        $fdata['type'] = 'form';

        foreach ($partyplayer->getInvites() as $invite) {
            $fdata["buttons"][] = ["text" => "$invite"];
        }

        $pk = new ModalFormRequestPacket();
        $pk->formId = 5002;
        $pk->formData = json_encode($fdata);
        $player->sendDataPacket($pk);
    }

    public function acceptInvite(Player $player)
    {
        $name = $player->getName();
        $fdata = [];
        $fdata['title'] = "§5Party§7 Invite";
        $fdata['buttons'] = [];
        $fdata['content'] = "";
        $fdata['type'] = 'form';

        $fdata["buttons"][] = ["text" => "§2Annehmen"];
        $fdata["buttons"][] = ["text" => "§4Ablehnen"];

        $pk = new ModalFormRequestPacket();
        $pk->formId = 5003;
        $pk->formData = json_encode($fdata);
        $player->sendDataPacket($pk);
    }

    public function selectClanWarsPlayer(Player $player)
    {
        $name = $player->getName();
        $partyplayer = Main::$partyplayers[$name];
        $clanplayer = Main::$players[$name];
        $fdata = [];

        $fdata['title'] = "§eClan§4Wars§7 Player";
        $fdata['buttons'] = [];

        $players = implode(",", $clanplayer->getClan()->getClanWarPlayers());
        $fdata['content'] = $players;
        $fdata['type'] = 'form';

        unset(self::$players[$name]["members"]);

        foreach ($clanplayer->getClan()->getMembers() as $member) {
            #if ($member !== $name) {
            if (Server::getInstance()->getPlayerExact($member) !== null) {
            if (!in_array($member, $clanplayer->getClan()->getClanWarPlayers())) {
                $fdata["buttons"][] = ["text" => "§7" . $member];
            } else {
                $fdata["buttons"][] = ["text" => "§a" . $member];
            }
            self::$players[$name]["members"][] = $member;
            }
            #}
        }
        $fdata["buttons"][] = ["text" => "§2Fertig"];
        self::$players[$name]["members"][] = "§2Fertig";

        $pk = new ModalFormRequestPacket();
        $pk->formId = 5004;
        $pk->formData = json_encode($fdata);
        $player->sendDataPacket($pk);
    }


    public function onDataPackets(DataPacketReceiveEvent $event)
    {
        $player = $event->getPlayer();
        $name = $player->getName();
        $packet = $event->getPacket();
        if ($packet instanceof ModalFormResponsePacket) {
            $partyplayer = Main::$partyplayers[$name];
            $clanplayer = Main::$players[$name];
            $id = $packet->formId;
            $data = json_decode($packet->formData);
            switch ($id) {
                case 5000:
                    if ($data === 0) {
                        if ($data !== null) {
                            if (!$partyplayer->isInParty()) {
                                $this->invitePlayer($player);
                            } elseif ($partyplayer->isPartyOwner()) {
                                $this->invitePlayer($player);
                            }
                        }
                    } elseif ($data === 1) {
                        if ($data !== null) {
                            if (!$partyplayer->isInParty()) {
                                $this->invites($player);
                            } elseif ($partyplayer->isPartyOwner()) {
                                #mp($partyplayer->getParty()->getPartyname());
                            }
                        }
                    } elseif ($data === 2) {
                        if ($data !== null) {
                            if ($clanplayer->isInClan()) {
                                if ($clanplayer->isClanLeader()) {
                                    $this->selectClanWarsPlayer($player);
                                }
                            }
                        }
                    } else if ($data === 3) {
                        if ($data !== null) {
                            if ($clanplayer->isClanWarPlayer()) {
                                $clanplayer->getClan()->removeClanWarPlayer($name);
                                $player->sendMessage("§7Du hast den Clan verlassen.");
                            }
                        }
                    }
                    break;
                case 5001:
                    if ($data !== null) {
                        if (!empty($data[0])) {
                            $invite = Server::getInstance()->getPlayer($data[0]);
                            if ($invite !== null) {
                                if (!$partyplayer->isInParty()) {
                                    $partyplayer->createParty();
                                    $player->sendMessage("§7Du hast eine Party erstellt.");
                                } else {
                                    $partyplayer->invitePayer($invite->getName());
                                }
                            } else {
                                $player->sendMessage("§7Dieser Spieler ist gerade nicht Online.");
                            }
                        }
                    }
                    break;
                case 5002:
                    if ($data !== null) {
                        $button = $partyplayer->getInvites()[$data];
                        #mp($button);
                        self::$member[$name] = $button;
                        $this->acceptInvite($player);
                    }
                    break;
                case 5003:
                    if ($data !== null) {
                        if ($data === true) {
                            $partyplayer->joinParty(self::$member[$name]);
                            $partyname = self::$member[$name];
                            $player->sendMessage("§7Du bist der Party von §2{$partyname}§7 beigetreten.");
                        }
                    }
                    break;
                case 5004:
                    if ($data !== null) {
                        $button = self::$players[$name]["members"][$data];

                        if ($button !== "§2Fertig") {
                            if (count($clanplayer->getClan()->getClanWarPlayers()) === 0) {
                                $clanplayer->getClan()->addClanWarPlayer($player->getName());
                            }

                            if (!in_array($button, $clanplayer->getClan()->getClanWarPlayers())) {
                                if (count($clanplayer->getClan()->getClanWarPlayers()) < 4) {
                                    $clanplayer->getClan()->addClanWarPlayer($button);
                                    $player->sendMessage("ADD");
                                } else {
                                    $player->sendMessage("§7Es können nur 4. Clan-Spieler bei einem ClanWar teilnehmen.");
                                }
                            } else {
                                $clanplayer->getClan()->removeClanWarPlayer($button);
                                $player->sendMessage("REMOVE");
                            }
                            $this->selectClanWarsPlayer($player);
                        }
                    }
                    break;
            }
        }
    }
}