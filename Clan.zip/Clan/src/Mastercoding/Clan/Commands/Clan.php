<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 16.11.2018
 * Time: 18:24
 */

namespace Mastercoding\Clan\Commands;


use function Composer\Autoload\includeFile;
use Mastercoding\Clan\Main;
use Mastercoding\Clan\task\mysqlTask;
use pocketmine\block\Barrier;
use pocketmine\block\Thin;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\ModalFormRequestPacket;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\utils\Config;

class Clan extends Command implements Listener
{

    public static $invites = [];
    public static $members = [];

    public function __construct($name, $description = "", $usageMessage = null, $aliases = [])
    {
        parent::__construct($name, $description, $usageMessage, $aliases);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            $this->openMainGui($sender);
        }
    }

    public function onConfig(): Config
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "invites.json", Config::JSON);
        $config->reload();
        return $config;
    }

    public function openMainGui(Player $player)
    {
        $name = $player->getName();
        $clanplayer = Main::$players[$player->getName()];

        $fdata = [];

        $fdata['title'] = "§eClan§7-§6System";
        $fdata['buttons'] = [];
        $fdata['content'] = "";
        $fdata['type'] = 'form';

        if (!$clanplayer->isInClan()) {
            $fdata["buttons"][] = ["text" => "§2Clan erstellen"];
            $fdata["buttons"][] = ["text" => "§2Einladungen"];
        } else {
            $fdata["buttons"][] = ["text" => "§3Member"];
            if ($clanplayer->isClanLeader() and count($clanplayer->getClan()->getLeaders()) === 1) {
                $fdata["buttons"][] = ["text" => "§2Einladen"];
                $fdata["buttons"][] = ["text" => "§4Clan Löschen"];
                $fdata["buttons"][] = ["text" => "§dParty"];
            } else if ($clanplayer->isClanLeader()) {
                $fdata["buttons"][] = ["text" => "§2Einladen"];
                $fdata["buttons"][] = ["text" => "§cClan verlassen"];
                $fdata["buttons"][] = ["text" => "§7ClanWar-Party"];
            } else {
                $fdata["buttons"][] = ["text" => "§cClan verlassen"];
            }
        }

        $pk = new ModalFormRequestPacket();
        $pk->formId = 4000;
        $pk->formData = json_encode($fdata);
        $player->sendDataPacket($pk);
    }

    public function onCreateClan(Player $player)
    {
        $fdata = [];

        $fdata['title'] = "§4Create§7-§4Clan";
        $fdata['buttons'] = [];
        $fdata['content'] = [];
        $fdata['type'] = 'custom_form';

        $fdata['content'][] = ["type" => "input", "text" => '§2Clan Name', "placeholder" => 'Name', 'default' => ''];
        $fdata['content'][] = ["type" => "input", "text" => '§2Clan Kürzel', "placeholder" => 'Kürzel', 'default' => ''];


        $pk = new ModalFormRequestPacket();
        $pk->formId = 4001;
        $pk->formData = json_encode($fdata);
        $player->sendDataPacket($pk);
    }

    public function InvitePlayer(Player $p)
    {
        $n = $p->getName();

        $fdata = [];

        $fdata['title'] = "§4Invite§7-§4Clan";
        $fdata['buttons'] = [];
        $fdata['content'] = [];
        $fdata['type'] = 'custom_form';

        $fdata['content'][] = ["type" => "input", "text" => '§2Einladen', "placeholder" => 'Name'];

        $pk = new ModalFormRequestPacket();
        $pk->formId = 4002;
        $pk->formData = json_encode($fdata);
        $p->sendDataPacket($pk);
    }


    public function getInvites(Player $player)
    {
        $name = $player->getName();
        $fdata = [];

        $fdata['title'] = "§4Clan§7-§2Invites";
        $fdata['buttons'] = [];
        $fdata['content'] = "";
        $fdata['type'] = 'form';


        $config = $this->onConfig();
        unset(self::$invites[$name]);
        foreach ($config->get($name) as $clans) {
            $fdata["buttons"][] = ["text" => $clans];
            self::$invites[$name][] = $clans;
        }

        $pk = new ModalFormRequestPacket();
        $pk->formId = 4003;
        $pk->formData = json_encode($fdata);
        $player->sendDataPacket($pk);
    }

    public function selectInvite(Player $player, string $clan)
    {
        $name = $player->getName();
        $fdata = [];
        $fdata['title'] = "§4Clan§7-§2Invite §3{$clan}";
        $fdata['buttons'] = [];
        $fdata['content'] = "§7Möchtest du dem Clan §2{$clan}§7 beitreten.";
        $fdata['type'] = 'modal';

        $fdata["button1"] = "§2Ja";
        $fdata["button2"] = "§4Nein";
        self::$invites[$name] = $clan;

        $pk = new ModalFormRequestPacket();
        $pk->formId = 4004;
        $pk->formData = json_encode($fdata);
        $player->sendDataPacket($pk);
    }

    public function ClanMembers(Player $p)
    {
        $name = $p->getName();
        $clanplayer = Main::$players[$name];
        try {
            $short = $clanplayer->getClan()->getClanshortname();

            $fdata = [];
            $fdata['title'] = "§4Clan§7-§2Members §f[§4{$short}§f]";
            $fdata['buttons'] = [];
            $fdata['content'] = "";
            $fdata['type'] = 'form';

            unset(self::$members[$name]);

            foreach ($clanplayer->getClan()->getMembers() as $member) {
                $fdata["buttons"][] = ["text" => $member];
                self::$members[$name][] = $member;
            }

            #mp(self::$members[$name]);

            $pk = new ModalFormRequestPacket();
            $pk->formId = 4005;
            $pk->formData = json_encode($fdata);
            $p->sendDataPacket($pk);
        }catch (\Error $error){
            null;
        }

    }

    public function clanLeave(Player $p)
    {
        $fdata = [];

        $fdata['title'] = "§7Clan-Leave";
        $fdata['content'] = "§4Möchtest du diesen Clan wirklich verlasssen?";
        $fdata['type'] = 'modal';

        $fdata["button1"] = "§2Ja";
        $fdata["button2"] = "§4Nein";

        $pk = new ModalFormRequestPacket();
        $pk->formId = 4006;
        $pk->formData = json_encode($fdata);
        $p->sendDataPacket($pk);
    }

    public function clanDelete(Player $p)
    {
        $fdata = [];

        $fdata['title'] = "§7Clan-Leave";
        $fdata['content'] = "§4Möchtest du diesen Clan wirklich löschen?";
        $fdata['type'] = 'modal';

        $fdata["button1"] = "§2Ja";
        $fdata["button2"] = "§4Nein";

        $pk = new ModalFormRequestPacket();
        $pk->formId = 4007;
        $pk->formData = json_encode($fdata);
        $p->sendDataPacket($pk);
    }

    public function selectModule(Player $player)
    {
        $name = $player->getName();
        $clanplayer = Main::$players[$player->getName()];

        $fdata = [];
        $fdata['title'] = "§7Clan§7-§eSystem";
        $fdata['buttons'] = [];
        $fdata['content'] = "";
        $fdata['type'] = 'form';

        $fdata["buttons"][] = ["text" => "§7Befördern"];
        $fdata["buttons"][] = ["text" => "§7Kicken"];

        $pk = new ModalFormRequestPacket();
        $pk->formId = 4008;
        $pk->formData = json_encode($fdata);
        $player->sendDataPacket($pk);
    }

    public function kickMember(Player $player, string $name)
    {
        $fdata = [];

        $fdata['title'] = "§7Clan-Leave";
        $fdata['content'] = "§7Möchtest du §2{$name}§7 wirklich aus dem Clan kicken?";
        $fdata['type'] = 'modal';

        $fdata["button1"] = "§2Ja";
        $fdata["button2"] = "§4Nein";

        $pk = new ModalFormRequestPacket();
        $pk->formId = 4009;
        $pk->formData = json_encode($fdata);
        $player->sendDataPacket($pk);
    }

    public function onDataPacket(DataPacketReceiveEvent $event)
    {
        $player = $event->getPlayer();
        $name = $player->getName();
        $packet = $event->getPacket();
        if ($packet instanceof ModalFormResponsePacket) {
            $clanplayer = Main::$players[$name];
            $id = $packet->formId;
            $data = json_decode($packet->formData);
            if ($id == 4000) {
                if ($data !== NULL) {
                    if (!$clanplayer->isInClan()) {
                        switch ($data) {
                            case 0:
                                $this->onCreateClan($player);
                                break;
                            case 1:
                                $this->getInvites($player);
                                break;
                        }
                    } elseif ($clanplayer->isInClan() and !$clanplayer->isClanLeader()) {
                        switch ($data) {
                            case 0:
                                $this->ClanMembers($player);
                                break;
                            case 1:
                                $this->clanLeave($player);
                                break;
                        }
                    } else if ($clanplayer->isClanLeader() and count($clanplayer->getClan()->getLeaders()) === 1) {
                        switch ($data) {
                            case 0:
                                $this->ClanMembers($player);
                                break;
                            case 1:
                                $this->InvitePlayer($player);
                                break;
                            case 2:
                                $this->clanDelete($player);
                                break;
                            case 3:
                                Main::getParty()->selectClanWarsPlayer($player);
                                break;
                        }
                    } else if ($clanplayer->isClanLeader()) {
                        switch ($data) {
                            case 0:
                                $this->ClanMembers($player);
                                break;
                            case 1:
                                $this->InvitePlayer($player);
                                break;
                            case 2:
                                $this->clanLeave($player);
                                break;
                            case 3:
                                Main::getParty()->selectClanWarsPlayer($player);
                                break;
                        }
                    }
                }
            }
            if ($id == 4001) {
                if ($data !== NULL) {
                    if (!empty($data[0])) {
                        if (strlen($data[0]) >= 5 and strlen($data[0]) <= 15) {
                            if (!empty($data[1])) {
                                if (strlen($data[1]) >= 2 and strlen($data[1]) <= 6) {

                                    $name = str_replace("§", "", $data[0]);
                                    $name = str_replace('\\', "", $name);
                                    $name = str_replace('.', "", $name);
                                    $name = str_replace(',', "", $name);
                                    $name = str_replace('-', "", $name);
                                    $name = str_replace('_', "", $name);
                                    $name = str_replace('(', "", $name);
                                    $name = str_replace(')', "", $name);
                                    $name = str_replace('"', "", $name);
                                    $name = str_replace("'", "", $name);
                                    $name = str_replace(';', "", $name);

                                    $k = str_replace("§", "", $data[1]);
                                    $k = str_replace("\\", "", $k);
                                    $k = str_replace(".", "", $k);
                                    $k = str_replace(",", "", $k);
                                    $k = str_replace("-", "", $k);
                                    $k = str_replace("_", "", $k);

                                    $k = str_replace("'", "", $k);
                                    $k = str_replace(")", "", $k);
                                    $k = str_replace("(", "", $k);
                                    $k = str_replace(":", "", $k);
                                    $k = str_replace(";", "", $k);
                                    $k = str_replace('"', "", $k);

                                    Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("SELECT * FROM clans WHERE clanname = '$name'", function (\mysqli_result $result, string $extra) {
                                        return $result->num_rows;
                                    }, function ($result, string $extra) {
                                        $array = explode(":", $extra);
                                        $clanplayer = Main::$players[$array[2]];
                                        if ($result <= 0) {
                                            $clanplayer->createClan($array[0], $array[1]);
                                            $clanplayer->getPlayer()->sendMessage("§7Du hast den Clan erfolgreich erstellt");
                                        } else {
                                            $clanplayer->getPlayer()->sendMessage("§7Diesen Clan gibt es schon.");
                                        }
                                    }, $name . ":" . $k . ":" . $clanplayer->getPlayer()->getName()));

                                } else {
                                    $player->sendMessage(Main::prefix . "§7Der Clan Kürzel muss zwischen 1 und 7 Buchstaben sein");
                                }
                            } else {
                                $player->sendMessage(Main::prefix . "§7Bitte gebe einen Clan-Kürzel an.");
                            }
                        } else {
                            $player->sendMessage(Main::prefix . "§7Der Clan Name muss zwischen 4 und 16 Buchstaben sein .");
                        }
                    } else {
                        $player->sendMessage(Main::prefix . "§7Bitte gebe einen Clan-Namen ein.");
                    }
                }
            }
            if ($id == 4002) {
                if ($data !== NULL) {
                    if (!empty($data[0])) {
                        $ep = Server::getInstance()->getPlayer($data[0]);
                        if ($ep !== NULL) {
                            $config = $this->onConfig();
                            $array = $config->get($ep->getName());
                            if (!in_array($clanplayer->getClan()->getClanname(), $array)) {
                                $array[] = $clanplayer->getClan()->getClanname();
                                $config->set($ep->getName(), $array);
                                $config->save();

                                $ep->sendMessage("§7Du hast eine Clan Anfrage von §2{$player->getDisplayName()} §7erhalten.");
                                $player->sendMessage("§7Du hast eine Clan Anfrage an §2{$ep->getName()}§7 geschickt");
                            } else {
                                $player->sendMessage("§7Du hast diesm Spieler schon eine Anfrage gesendet");
                            }
                        } else {
                            $config = $this->onConfig();
                            if ($config->exists($data[0])) {
                                $array = $config->get($data[0]);
                                $array[] = $clanplayer->getClan()->getClanname();
                                $config->set($data[0], $array);
                            } else {
                                $player->sendMessage(Main::prefix . "§4Dieser Spieler ist nicht registriert");
                            }
                        }
                    }
                }
            }
            if ($id === 4003) {
                if ($data !== NULL) {
                    $button = self::$invites[$name][$data];
                    #mp($button);
                    $this->selectInvite($player, $button);
                }
            }
            if ($id === 4004) {
                if ($data !== NULL) {
                    if ($data === true) {
                        if (!$clanplayer->isInClan()) {
                            $clanplayer->joinClan(self::$invites[$name]);
                            $clan = self::$invites[$name];

                            $config = $this->onConfig();
                            $array = $config->get($name);
                            $search = array_search($clan, $array);
                            unset($array[$search]);
                            $config->set($name, $array);
                            $config->save();

                            $player->sendMessage("§7Du bist dem Clan {$clan} beigetreten");
                        } else {
                            $player->sendMessage("§7Du musst deinen anderen Clan zu erst verlassen.");
                        }
                    }
                }
            }
            if ($id === 4005) {
                if ($data !== NULL) {
                    if ($clanplayer->isInClan()) {
                        $button = self::$members[$name][$data];
                        #mp($button);
                        self::$members[$name] = $button;
                        $this->selectModule($player);
                    }
                }
            }
            if ($id === 4006) {
                if ($data !== NULL) {
                    if ($data === true) {
                        if ($clanplayer->isInClan()) {
                            $clanplayer->leaveClan();
                        }
                    }
                }
            }
            if ($id === 4007) {
                if ($data !== NULL) {
                    if ($data === true) {
                        if ($clanplayer->isClanLeader()) {
                            $clanplayer->deleteClan();
                            $player->sendMessage("§7Der Clan wurde erfolgreich gelöscht.");
                        }
                    }
                }
            }
            if ($id === 4008) {
                if ($data !== NULL) {
                    switch ($data) {
                        case 0:
                            if ($clanplayer->isClanLeader()) {
                                if ($clanplayer->getClan()->addLeader(self::$members[$name], $name)) {
                                    $member = self::$members[$name];
                                    #$player->sendMessage("§2{$member}§7 ist nun ein Leader");
                                } else {
                                    $player->sendMessage("§7Es können nur Maximal 3. Member Leader sein.");
                                }
                            } else {
                                $player->sendMessage("§7Du hast keine Rechte einen Member zu promoten.");
                            }
                            break;
                        case 1:
                            if ($clanplayer->isClanLeader()) {
                                if ($this->kickMember($player, self::$members[$name]) === false) {
                                    $player->sendMessage("§7Es muss mindestens einen Leader geben.");
                                } else {

                                }
                            } else {
                                $player->sendMessage("§7Du hast keine Rechte einen Member zu kicken.");
                            }
                            break;
                    }
                }
            }
            if ($id === 4009) {
                if ($data !== null) {
                    if ($data === true) {
                        if ($clanplayer->isClanLeader()) {
                            if (isset(Main::$players[self::$members[$name]])) {
                                $kicked = Main::$players[self::$members[$name]];
                                $clanplayer->getClan()->kickMember(self::$members[$name]);
                            } else {
                                $clanplayer->getClan()->kickMember(self::$members[$name]);
                            }
                        }
                    }
                }
            }
        }
    }

    public function onLogin(PlayerLoginEvent $event)
    {
        $player = $event->getPlayer();
        $name = $player->getName();
        $config = $this->onConfig();
        if (!$config->exists($name)) {
            $config->set($name, []);
            $config->save();
        }
    }

}