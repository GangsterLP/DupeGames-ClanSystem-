<?php
/**
 * Created by PhpStorm.
 * User: mastercoding
 * Date: 07.03.19
 * Time: 23:37
 */
namespace Mastercoding\Clan\Commands;

use Mastercoding\Clan\db;
use Mastercoding\Clan\task\mysqlTask;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\Server;

class VerivyCommand extends Command {

    public function __construct($name, $description = "", $usageMessage = null, $aliases = [])
    {
        parent::__construct($name, $description, $usageMessage, $aliases);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {

        if ($sender instanceof Player){
            if (!empty($args[0])){
                if (is_numeric($args[0])){
                    Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("SELECT * FROM users WHERE token = '$args[0]'", function (\mysqli_result $result, string $extra){
                        if ($result->num_rows <= 0){
                            return false;
                        }else{
                            $db = new db();
                            $conn = $db->connect();
                            $uid = $result->fetch_assoc()["uid"];
                            $conn->query("UPDATE users SET mcname = '$extra' WHERE uid = $uid");
                            return true;
                        }
                    }, function ($result, string $extra){
                        $player = Server::getInstance()->getPlayerExact($extra);
                        if ($player !== null){
                            if ($result){
                                $player->sendMessage("§2Du wurdest Verifiziert.");
                            }else{
                                $player->sendMessage("§4Der Token ist ungültig.");
                            }
                        }

                    },$sender->getName()));
                }else{
                    $sender->sendMessage("§7Der Token besteht nur aus Zahlen.");
                }
            }else{
                $sender->sendMessage("§2/verify §7<§atoken§7>");
            }
        }
    }
}