<?php
/**
 * Created by PhpStorm.
 * User: mastercoding
 * Date: 07.03.19
 * Time: 00:19
 */
namespace Mastercoding\Clan;

use pocketmine\block\Thin;

class partyClass {

    protected $partyname;
    protected $members = [];

    public function __construct(?string $party, array $members)
    {
        $this->partyname = $party;
        $this->members = $members;
    }

    public function getPartyPlayers()
    {
        $members = [];
        foreach ($this->members as $member) {
            if (isset(Main::$partys[$member])) {
                $members[] = Main::$partys[$member];
            }
        }
        return $members;
    }

    public function addMember(string $name){
        $this->members[] = $name;
    }

    public function removeMember(string $name){
        $search = array_search($name, $this->members);
        unset($this->members[$search]);
    }

    public function getPartyOwner(): string
    {
        return $this->partyname;
    }

    public function deleteParty() {
        foreach ($this->getPartyPlayers() as $partyPlayer){
            if ($partyPlayer->getPlayer()->getName() !== $this->getPartyOwner()) {
                $partyPlayer->getPlayer()->sendMessage("§7Du wurdest aus der Party gekickt, da der Owner die Party gelöscht hat.");
                $this->removeMember($partyPlayer->getPlayer()->getName());
            }
        }
        if (isset(Main::$partyplayers[$this->getPartyOwner()])){
            Main::$partyplayers[$this->getPartyOwner()]->getPlayer()->sendMessage("§7Die Party wurde aufgelöst.");
        }
        unset(Main::$partys[$this->getPartyOwner()]);
        #mp(Main::$partys);
    }

    /**
     * @return array
     */
    public function getMembers(): array
    {
        return $this->members;
    }

    /**
     * @return string|null
     */
    public function getPartyname(): ?string
    {
        return $this->partyname;
    }
}