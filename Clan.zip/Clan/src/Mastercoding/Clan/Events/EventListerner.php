<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 16.11.2018
 * Time: 18:23
 */

namespace Mastercoding\Clan\Events;

use Mastercoding\Clan\Main;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;

class EventListerner implements Listener {
    public $pl;

    public function __construct(Main $pl)
    {
        $this->pl = $pl;
    }
}