<?php
/**
 * Created by PhpStorm.
 * User: mastercoding
 * Date: 06.03.19
 * Time: 12:52
 */
namespace Mastercoding\Clan;
class db {
    const HOST = "78.143.39.39";
    const USER = "ni1256933_2sql3";
    const PASS = "MasterFlo187";
    const DB   = "ni1256933_2sql3";

    public function connect():\mysqli {
        return mysqli_connect(self::HOST, self::USER, self::PASS, self::DB);
    }
}
