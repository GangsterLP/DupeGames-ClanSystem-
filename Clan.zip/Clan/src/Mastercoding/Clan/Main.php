<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 16.11.2018
 * Time: 18:21
 */

namespace Mastercoding\Clan;

use Mastercoding\Admin\CMD\Party\Party;
use Mastercoding\Clan\Commands\Clan;
use Mastercoding\Clan\Commands\PartyCommand;
use Mastercoding\Clan\Commands\VerivyCommand;
use Mastercoding\Clan\Events\EventListerner;
use Mastercoding\Clan\task\mysqlTask;
use Mastercoding\ClanWars\Utils\Elo;
use pocketmine\block\Thin;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\ItemFactory;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener
{
    const prefix = "§4Clan§7│";
    public $group;

    /** @var clanPlayer[] */
    public static $players = [];

    /** @var clanClass[] */
    public static $clans = [];

    /** @var partyClass[] */
    public static $partys = [];

    /** @var partyPlayer[] */
    public static $partyplayers = [];

    public static $instance;

    public static $party;

    public function onEnable()
    {
        $instance = $this;
        $this->getServer()->getPluginManager()->registerEvents($instance, $this);
        self::$instance = $instance;

        $this->getLogger()->notice("§2Clans geladen");

        $this->group = $this->getServer()->getPluginManager()->getPlugin("Cloud-Group");

        $clan = new Clan("clan", "clan");
        $this->getServer()->getPluginManager()->registerEvents($clan, $this);
        $this->getServer()->getCommandMap()->register("clan", $clan);

        $party = new PartyCommand("party", "party", "Party", ["p"]);
        $this->getServer()->getPluginManager()->registerEvents($party, $this);
        $this->getServer()->getCommandMap()->register("party", $party);
        self::$party = $party;

        $verify = new VerivyCommand("verify", "Verify Clan Webinterface");
        $this->getServer()->getCommandMap()->register("verify", $verify);
    }

    public function onJoin(PlayerLoginEvent $event)
    {
        $player = $event->getPlayer();
        $name = $player->getName();
        $this->updateAll($player);
        $this->updateParty($player);
        PartyCommand::$players[$name]["count"] = 1;
    }

    public function onQuit(PlayerQuitEvent $event)
    {
        $player = $event->getPlayer();
        $name = $player->getName();
        $clanplayer = Main::$players[$name];
        if ($clanplayer->isInClan()) {
            if (!$clanplayer->getClan()->isInGame()) {
                if ($clanplayer->isClanWarPlayer()) {
                    $clanplayer->getClan()->removeClanWarPlayer($name);
                }
            }
        }
    }

    public function updateParty(Player $player)
    {
        $name = $player->getName();
        Main::$partyplayers[$name] = new partyPlayer($player);
    }

    public function updateAll(Player $player)
    {
        $name = $player->getName();
        Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("SELECT * FROM mcplayer WHERE mcname = '$name'", function (\mysqli_result $result, string $extra) {
            if ($result->num_rows <= 0) {
                $db = new db();
                $conn = $db->connect();
                $conn->query("INSERT INTO mcplayer (mcname) VALUES ('$extra')");
                $res = $conn->query("SELECT * FROM mcplayer WHERE mcname = '$extra'");

                $short = $res->fetch_array()["clanname"];
                $res2 = $conn->query("SELECT shortname FROM clans WHERE clanname = '$short'");

                $members = [];
                $res3 = $conn->query("SELECT * FROM mcplayer WHERE clanname = '$short'")->fetch_all(MYSQLI_ASSOC);
                foreach ($res3 as $row) {
                    $members[] = $row["mcname"];
                }

                return [1 => $res->fetch_assoc(), 2 => $res2->fetch_array(), 3 => $members, 4 => 0];
            } else {
                $db = new db();
                $conn = $db->connect();

                $result = $conn->query("SELECT * FROM mcplayer WHERE mcname = '$extra'")->fetch_array();
                #mp($result);

                $short = $result["clanname"];
                $res2 = $conn->query("SELECT * FROM clans WHERE clanname = '$short'");

                $members = [];

                $res3 = $conn->query("SELECT * FROM mcplayer WHERE clanname = '$short'")->fetch_all(MYSQLI_ASSOC);
                foreach ($res3 as $row) {
                    $members[] = $row["mcname"];
                    #mp($row["mcname"]);
                }

                $stats = $conn->query("SELECT elo FROM stats WHERE clanname = '$short'")->fetch_assoc();
                #mp($stats);

                return [1 => $result, 2 => $res2->fetch_array(), 3 => $members, 4 => $stats];
            }
        }, function ($result, string $extra) {
            $player = Server::getInstance()->getPlayerExact($extra);
            if ($player !== null) {
                $leaders = explode(":", $result[2]["leaders"]);

                array_pop($leaders);
                #mp($leaders);

                if (!isset(Main::$clans[$result[1]["clanname"]])) {
                    if ($result[1]["clanname"] !== null) {
                    	if (!empty($result[4])){
                        Main::$clans[$result[1]["clanname"]] = new clanClass($result[1]["clanname"], $result[2]["shortname"], $leaders, $result[3], $result[4]["elo"]);
                        }
                    }
                }

                Main::$players[$extra] = new clanPlayer($player, $result[1]["clanname"]);
            }
        }, $name));
    }

    /**
     * @return self
     */
    public static function getInstance(): self
    {
        return self::$instance;
    }

    /**
     * @return mixed
     */
    public static function getParty() : PartyCommand
    {
        return self::$party;
    }

}
