<?php
/**
 * Created by PhpStorm.
 * User: mastercoding
 * Date: 07.03.19
 * Time: 00:06
 */

namespace Mastercoding\Clan;

use Mastercoding\Admin\Proxy\ThreadPool;
use pocketmine\block\Thin;
use pocketmine\Player;

class partyPlayer
{

    protected $player;
    protected $party;

    protected $members = [];
    protected $invites = [];

    public function __construct(Player $player)
    {
        $this->player = $player;
    }

    public function isInParty(): bool
    {
        return !is_null($this->party);
    }

    public function createParty()
    {
        $this->party = $this->getPlayer()->getName();
        Main::$partys[$this->getPlayer()->getName()] = new partyClass($this->getPlayer()->getName(), [$this->getPlayer()->getName()]);
    }

    public function leaveParty()
    {
        if ($this->isInParty()) {
            if ($this->getParty()->getPartyOwner() !== $this->getPlayer()->getName()) {
                $this->getParty()->removeMember($this->getPlayer()->getName());
            }else{
                $this->getParty()->deleteParty();
            }
        }
    }

    public function isPartyOwner() : bool {
        return $this->party == $this->getPlayer()->getName();
    }

    public function joinParty(string $name)
    {
        if (!$this->isInParty()){
            $search = array_search($this->getPlayer()->getName(), $this->invites);
            #mp($search);
            unset($this->invites[$search]);
            $this->party = $name;
            $this->getParty()->addMember($this->getPlayer()->getName());
        }else{

        }
    }

    public function invitePayer(string $name){
        if (isset(Main::$partyplayers[$name])) {
            $player = Main::$partyplayers[$name];
            $player->invites[] = $name;
            $this->getPlayer()->sendMessage("§7Du hast §2{$player->getPlayer()->getName()}§7 in deine Party eingeladen.");
            $player->getPlayer()->sendMessage("§7Du hast eine §6Party §7Anfrage von §2{$this->getPlayer()->getName()}§7 erhalten.");
        }else{
            #mp("gishthg");
        }
    }

    public function getInvites() : array {
        return $this->invites;
    }

    /**
     * @return partyPlayer|null
     */
    public function getParty(): ?partyClass
    {
        return Main::$partys[$this->party];
    }

    /**
     * @return Player
     */
    public function getPlayer(): Player
    {
        return $this->player;
    }
}