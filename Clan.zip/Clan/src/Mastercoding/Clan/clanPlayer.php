<?php
/**
 * Created by PhpStorm.
 * User: mastercoding
 * Date: 06.03.19
 * Time: 13:00
 */

namespace Mastercoding\Clan;

use Mastercoding\Clan\task\mysqlTask;
use pocketmine\block\Thin;
use pocketmine\Player;
use pocketmine\Server;

class clanPlayer
{

    protected $player;
    protected $clanname;


    public function __construct(Player $player, ?string $clanname)
    {
        $this->player = $player;
        $this->clanname = $clanname;
        #mp($clanname);
    }

    public function createClan(string $clanname, string $shortname)
    {
        $player = $this->getPlayer()->getName();
        Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("INSERT INTO clans (clanname, shortname, leaders) VALUES ('$clanname', '$shortname', '$player:')"));
        Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("INSERT INTO stats (clanname, wins, loses, elo) VALUES ('$clanname', 0, 0, 1000)"));
        Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("UPDATE mcplayer SET clanname = '$clanname' WHERE mcname = '$player'"));
        Main::$clans[$clanname] = new clanClass($clanname, $shortname, [$player], [$player], 1000);
        $this->clanname = $clanname;

        Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("INSERT INTO lastbattles (clanname, lid) VALUES ('$clanname', 0)"));
    }

    public function joinClan(string $clan)
    {
        $this->clanname = $clan;
        try {
            $this->getClan()->addMember($this->getPlayer()->getName());
        }catch (\Error $error){
            null;
        }
    }

    public function isClanLeader()
    {
        try {
            return in_array($this->player->getName(), $this->getClan()->getLeaders());
        }catch (\Error $error){
            null;
        }
    }

    public function isClanWarPlayer(): bool
    {
        return in_array($this->getPlayer()->getName(), $this->getClan()->getClanWarPlayers());
    }

    /**
     * @return clanClass|null
     */
    public function getClan(): ?clanClass
    {
        if (isset(Main::$clans[$this->clanname])){
            return Main::$clans[$this->clanname];
        }else{
            return null;
        }
    }


    public function isInClan(): bool
    {
        return !is_null($this->clanname);
    }

    /**
     * @return Player
     */
    public function getPlayer(): Player
    {
        return $this->player;
    }

    public function leaveClan()
    {
        if ($this->getClan() !== null) {
            $this->getClan()->removeMember($this->getPlayer()->getName());
            if ($this->isClanLeader()) {
                $this->getClan()->removeLeader($this->getPlayer()->getName());

            }
        }
        $this->clanname = null;
    }

    public function deleteClan()
    {
        if ($this->isInClan()) {
            $name = $this->getPlayer()->getName();

            foreach ($this->getClan()->getMembers() as $member) {
                Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("DELETE FROM mcplayer WHERE mcname = '$member'"));
            }

            Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("DELETE FROM clans WHERE clanname = '$this->clanname'"));
            Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("DELETE FROM mcplayer WHERE mcname = '$name'"));
            Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("DELETE FROM stats WHERE clanname = '$this->clanname'"));
            $this->clanname = null;
        }
    }
}