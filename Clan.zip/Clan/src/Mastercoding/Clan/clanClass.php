<?php
/**
 * Created by PhpStorm.
 * User: mastercoding
 * Date: 06.03.19
 * Time: 13:34
 */

namespace Mastercoding\Clan;

use Mastercoding\Clan\task\mysqlTask;
use pocketmine\block\Thin;
use pocketmine\level\Level;
use pocketmine\Server;

class clanClass
{

    protected $clanname;
    protected $clanshortname;

    protected $leaders = [];
    protected $members = [];

    protected $clanwarsplayers = [];
    protected $ingame;
    protected $pos;

    protected $level;

    protected $elo;
    protected $team;

    public function __construct(?string $clanname, ?string $clanshortname, array $leaders, array $members, int $elo)
    {
        $this->clanname = $clanname;
        $this->clanshortname = $clanshortname;
        $this->leaders = $leaders;
        $this->members = $members;
        $this->elo = $elo;
    }


    /**
     * @return string|null
     */
    public function getClanname(): ?string
    {
        return $this->clanname;
    }

    /**
     * @param string|null $clanname
     */
    public function setClanname(?string $clanname): void
    {
        Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("UPDATE clans SET clanname = '$clanname' WHERE clanname = '{$this->getClanname()}'"));
        $this->clanname = $clanname;
    }

    /**
     * @return string|null
     */
    public function getClanshortname(): ?string
    {
        return $this->clanshortname;
    }

    /**
     * @param string|null $shortname
     */
    public function setClanshortname(?string $shortname): void
    {
        $this->clanshortname = $shortname;
        Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("UPDATE clans SET shortname = '$shortname' WHERE clanname = '{$this->getClanname()}'"));
    }

    /**
     * @return array
     */
    public function getMembers(): array
    {
        return $this->members;
    }

    public function addMember(string $name)
    {
        $this->members[] = $name;
        Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("UPDATE mcplayer SET clanname = '{$this->getClanname()}' WHERE mcname = '$name'"));
    }

    public function addClanWarPlayer(string $name)
    {
        $this->clanwarsplayers[] = $name;
    }

    public function removeClanWarPlayer(string $name)
    {
        $search = array_search($name, $this->clanwarsplayers);
        unset($this->clanwarsplayers[$search]);
    }

    public function getClanWarPlayers(): array
    {
        return $this->clanwarsplayers;
    }

    public function removeMember(string $name)
    {
        $search = array_search($name, $this->members);
        unset($this->members[$search]);

        Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("DELETE FROM mcplayer WHERE mcname = '$name'"));
        if (isset(Main::$players[$name])) {
            Main::getInstance()->updateAll(Server::getInstance()->getPlayerExact($name));
        }
    }

    public function kickMember(string $name): bool
    {
        if (in_array($name, $this->getLeaders())) {
            if (count($this->getLeaders()) > 1) {
                foreach ($this->getMembers() as $member) {
                    if (isset(Main::$players[$member])) {
                        Main::$players[$member]->getPlayer()->sendMessage("§2{$name} §7wurde degradiert.");
                    }
                }
                $this->removeLeader($name);
                return true;
            } else {
                return false;
            }
        } else {
            $player = Server::getInstance()->getPlayerExact($name);
            if ($player !== null) {
                $player->sendMessage("§7Du wurdest aus dem Clan §2{$this->getClanname()}§7 gekickt.");
            }
            $this->removeMember($name);

            foreach ($this->getMembers() as $member) {
                if (isset(Main::$players[$member])) {
                    Main::$players[$member]->getPlayer()->sendMessage("§2{$name} §7wurde aus dem Clan gekickt.");
                }
            }
            return true;
        }
    }

    /**
     * @return array
     */
    public function getLeaders(): array
    {
        return $this->leaders;
    }

    public function addLeader(string $name, string $von)
    {
        if (count($this->getLeaders()) < 4) {
            if (isset(Main::$players[$name])) {
                if (!Main::$players[$name]->isClanLeader()) {
                    $array = $this->getLeaders();
                    $array[] = $name;
                    $text = implode(":", $array);
                    $text .= ":";

                    Main::$players[$name]->getPlayer()->sendMessage("§7Du bist nun ein Leader.");
                    Main::$players[$von]->getPlayer()->sendMessage("§7Du hast §2{$name}§7 zu einem Leader gemacht.");
                    Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("UPDATE clans SET leaders = '$text' WHERE clanname = '$this->clanname'"));
                } else {
                    $clanplayer = Main::$players[$von];
                    $clanplayer->getPlayer()->sendMessage("§7Du kannst keinen Leader zum Leader machen.");
                }
            } else {
                $clanplayer = Main::$players[$von];
                $clanplayer->getPlayer()->sendMessage("§7Der Spieler muss online sein um ihn Leader zu machen.");
            }
            return true;
        }else{
            return false;
        }
    }

    public function removeLeader(string $name)
    {
        if (in_array($name, $this->leaders)) {
            $search = array_search($name, $this->leaders);
            unset($this->leaders[$search]);
            $text = implode(":", $this->leaders);
            if (count($this->getLeaders()) !== 0) {
                $text .= ":";
            }
            Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("UPDATE clans SET leaders = '$text' WHERE clanname = '$this->clanname'"));
        }
    }

    public function setIngame(bool $bool){
        $this->ingame = $bool;
    }

    public function isInGame(){
        return $this->ingame;
    }

    public function getPos(int $pos){
        $this->pos = $pos;
    }

    public function setPos(){
        return $this->pos;
    }

    public function setLevel(Level $level){
        $this->level = $level;
    }

    public function getLevel() : ?Level {
        return $this->level;
    }

    public function getElo(){
        return $this->elo;
    }

    public function addElo(int $elo){
        Server::getInstance()->getAsyncPool()->submitTask(new mysqlTask("UPDATE stats SET elo = elo + $elo WHERE clanname = '$this->clanname'"));
        $this->elo += $elo;
    }

    public function setTeam(int $team){
        $this->team = $team;
    }

    public function getTeam(){
        return $this->team;
    }
}